
'use client';

import { useState, useEffect } from 'react';
import { Question, getRandomQuestions } from '../lib/questions';
import QuestionCard from '../components/QuestionCard';
import ProgressBar from '../components/ProgressBar';
import ResultModal from '../components/ResultModal';

export default function Home() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [userAnswers, setUserAnswers] = useState<string[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [quizStarted, setQuizStarted] = useState(false);

  useEffect(() => {
    if (quizStarted && questions.length === 0) {
      const randomQuestions = getRandomQuestions(15);
      setQuestions(randomQuestions);
    }
  }, [quizStarted, questions.length]);

  const startQuiz = () => {
    setQuizStarted(true);
    setQuestions(getRandomQuestions(15));
    setCurrentQuestionIndex(0);
    setUserAnswers([]);
    setSelectedAnswer(null);
    setShowModal(false);
  };

  const handleAnswerSelect = (answer: string) => {
    setSelectedAnswer(answer);
  };

  const handleNext = () => {
    if (!selectedAnswer) return;

    const newAnswers = [...userAnswers, selectedAnswer];
    setUserAnswers(newAnswers);

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
    } else {
      setShowModal(true);
    }
  };

  const calculateScore = () => {
    return userAnswers.reduce((score, answer, index) => {
      return score + (answer === questions[index]?.correct_answer ? 1 : 0);
    }, 0) + (selectedAnswer === questions[currentQuestionIndex]?.correct_answer ? 1 : 0);
  };

  const getIncorrectQuestions = () => {
    const incorrect: Question[] = [];
    userAnswers.forEach((answer, index) => {
      if (answer !== questions[index]?.correct_answer) {
        incorrect.push(questions[index]);
      }
    });
    if (selectedAnswer !== questions[currentQuestionIndex]?.correct_answer) {
      incorrect.push(questions[currentQuestionIndex]);
    }
    return incorrect;
  };

  if (!quizStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="w-20 h-20 mx-auto mb-6 bg-blue-500 rounded-full flex items-center justify-center">
            <i className="ri-graduation-cap-line text-3xl text-white"></i>
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-6">
            Simulado LK3 Cursos: ENEM
          </h1>
          <div className="space-y-4 mb-6">
            <div className="flex items-center gap-3 text-left">
              <div className="w-6 h-6 flex items-center justify-center">
                <i className="ri-question-line text-blue-500 text-lg"></i>
              </div>
              <p className="text-gray-600 text-sm">
                15 questões aleatórias do ENEM
              </p>
            </div>
            <div className="flex items-center gap-3 text-left">
              <div className="w-6 h-6 flex items-center justify-center">
                <i className="ri-shuffle-line text-blue-500 text-lg"></i>
              </div>
              <p className="text-gray-600 text-sm">
                Diferentes matérias em cada simulado
              </p>
            </div>
            <div className="flex items-center gap-3 text-left">
              <div className="w-6 h-6 flex items-center justify-center">
                <i className="ri-calendar-line text-blue-500 text-lg"></i>
              </div>
              <p className="text-gray-600 text-sm">
                Questões de diversos anos de prova
              </p>
            </div>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <p className="text-green-700 text-sm font-medium">
              ✨ Você pode fazer o simulado gratuitamente quantas vezes desejar!
            </p>
          </div>
          <button
            onClick={startQuiz}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-4 px-6 rounded-lg transition-colors duration-200 !rounded-button"
          >
            Iniciar Simulado
          </button>
        </div>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando questões...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <div className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-sm border-b border-gray-200 z-40">
          <div className="container mx-auto px-4 py-4">
            <ProgressBar 
              current={currentQuestionIndex + 1} 
              total={questions.length} 
            />
          </div>
        </div>

        <div className="pt-24 pb-8">
          <QuestionCard
            question={questions[currentQuestionIndex]}
            questionNumber={currentQuestionIndex + 1}
            selectedAnswer={selectedAnswer}
            onAnswerSelect={handleAnswerSelect}
            onNext={handleNext}
          />
        </div>

        <ResultModal
          isOpen={showModal}
          score={calculateScore()}
          totalQuestions={questions.length}
          userAnswers={[...userAnswers, selectedAnswer || '']}
          questions={questions}
          onClose={() => setShowModal(false)}
          onRestart={startQuiz}
        />
      </div>
    </div>
  );
}
